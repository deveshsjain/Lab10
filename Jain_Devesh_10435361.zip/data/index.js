const userdata = require('./users');

module.exports = {
    users: userdata
};